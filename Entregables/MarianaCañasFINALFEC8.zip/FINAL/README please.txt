GRACIAS, profe!! le puse mucho empeño, sé que hay bastante para corregir todavía.

Un saludo.
Mariana.